package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Time;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class Game extends AppCompatActivity implements View.OnClickListener {
    //timer
    private static final long COUNTDOWN_IN_MILLIS = 60000;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;
    private TextView timer;
    //timer
    private TextView playerOneScore, playerTwoScore, Turn, player, player0;
    private Button[] buttons = new Button[9];


    private int playerOneScoreCount, playerTwoScoreCount, roundCount;
    boolean activePlayer;
    private TextView player1, player2, pass;

    //p1 => 0
    //p2 => 1
    //empty => 2

    int[] gameState = {2, 2, 2, 2, 2, 2, 2, 2, 2};
    int[][] winningPositions = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, //rows
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, //column
            {0, 4, 8}, {2, 4, 6} //diagonal
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        //timer
        timer = findViewById(R.id.timer);
        //timer
        player1 = (TextView) findViewById(R.id.playerOne);
        player2 = (TextView) findViewById(R.id.playerTwo);
        playerOneScore = (TextView) findViewById(R.id.playerOneScore);
        playerTwoScore = (TextView) findViewById(R.id.playerTwoScore);
        Turn = (TextView) findViewById(R.id.turn);

        pass = (TextView) findViewById(R.id.turn);
        ImageButton imageButton = (ImageButton) findViewById(R.id.imageHome);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent packageContext;
                Intent intent = new Intent (Game.this,Home.class);
                startActivity( intent );
                finish();
            }
        });

        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder= new AlertDialog.Builder(Game.this);
                builder.setMessage("Are you sure you want to exit?");
                builder.setCancelable(true);
                builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                        System.exit(0);
                    }
                });
                builder.setPositiveButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }});

        String edit_text1 = getIntent().getStringExtra("playerOne");
        String edit_text2 = getIntent().getStringExtra("playerTwo");
        player1.setText(edit_text1);
        player2.setText(edit_text2);

        for (int i = 0; i < buttons.length; i++) {
            String buttonID = "btn" + i;
            int resourceID = getResources().getIdentifier(buttonID, "id", getPackageName());
            buttons[i] = (Button) findViewById(resourceID);
            buttons[i].setOnClickListener(this);
        }
        roundCount = 0;
        playerOneScoreCount = 0;
        playerTwoScoreCount = 0;
        activePlayer = true;

        if (roundCount==0){
            timeLeftInMillis = COUNTDOWN_IN_MILLIS;
            startCountDown();
        }
    }



    @Override
    public void onClick(View view) {



        if (!((Button) view).getText().toString().equals("")) {
            return;
        }
        String buttonID = view.getResources().getResourceEntryName(view.getId());
        int gameStatePointer = Integer.parseInt(buttonID.substring(buttonID.length() - 1, buttonID.length()));

        if (activePlayer) {
            ((Button) view).setText("X");
            ((Button) view).setTextColor(Color.parseColor("#FFC34A"));
            gameState[gameStatePointer] = 0;
        }
        else {
            ((Button) view).setText("O");
            ((Button) view).setTextColor(Color.parseColor("#800080"));
            gameState[gameStatePointer] = 1;
        }
        roundCount++;

        if (checkWinner()) {
            if (activePlayer) {
                playerOneScoreCount++;
                updatePlayerScore();
                Toast.makeText(this, "Player 1 Won !", Toast.LENGTH_SHORT).show();
                playAgain();
            } else {
                playerTwoScoreCount++;
                updatePlayerScore();
                Toast.makeText(this, "Player 2 Won !", Toast.LENGTH_SHORT).show();
                playAgain();
            }
        } else if (roundCount == 9) {
            Toast.makeText(this, "No Winner !", Toast.LENGTH_SHORT).show();
            playAgain();
        } else {
            activePlayer = !activePlayer;
        }
        if (playerOneScoreCount > playerTwoScoreCount) {
            Turn.setText("X wins the game.");
            } else if (playerTwoScoreCount > playerOneScoreCount) {
            Turn.setText("O wins the game.");
        }
        else if (playerTwoScoreCount == playerTwoScoreCount){
            Turn.setText("The score is tie.");
        }
            else
         {
            Turn.setText("");
        }
    }
    private void startCountDown (){
        countDownTimer = new CountDownTimer(timeLeftInMillis,1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                timeLeftInMillis = 0;
                updateCountDownText();
                String winner = pass.getText().toString();
                Intent intent = new Intent(getApplicationContext(),ResultActivity.class);
                intent.putExtra("winnerRes", winner);
                startActivity(intent);

            }
        }.start();
    }
    private void updateCountDownText() {
        int minutes = (int)(timeLeftInMillis / 1000)/60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        String timeFormatted = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);


        timer.setText(timeFormatted);

        if(timeLeftInMillis < 10000){
            timer.setTextColor(Color.RED);
        }else{
            timer.setTextColor(Color.BLACK);
        }
    }
    public boolean checkWinner() {
        boolean winnerResult = false;

        for (int[] winningPosions : winningPositions) {
            if (gameState[winningPosions[0]] == gameState[winningPosions[1]] && gameState[winningPosions[1]] == gameState[winningPosions[2]] && gameState[winningPosions[0]] != 2) {
                winnerResult = true;
            }
        }
        return winnerResult;
    }

    public void updatePlayerScore() {
        playerOneScore.setText(Integer.toString(playerOneScoreCount));
        playerTwoScore.setText(Integer.toString(playerTwoScoreCount));
    }

    public void playAgain() {
        roundCount = 0;
        activePlayer = true;


        for (int i = 0; i < buttons.length; i++) {
            gameState[i] = 2;
            buttons[i].setText("");
        }
    }

}


