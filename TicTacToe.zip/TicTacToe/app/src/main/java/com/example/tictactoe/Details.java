package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class Details extends AppCompatActivity {
    private EditText player1;
    private EditText player2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();

        player1 = findViewById(R.id.edit_text1);
        player2 = findViewById(R.id.edit_text2);


        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(player1.getText().toString())){
                    player1.setError("Please enter your name.");
                    return;
                }
                if (TextUtils.isEmpty(player2.getText().toString())){
                    player2.setError("Please enter your name.");
                    return;
                }
                else{
                String edit_text1 = player1.getText().toString();
                String edit_text2 = player2.getText().toString();
                Intent intent = new Intent(Details.this, Game.class);
                intent.putExtra("playerOne", edit_text1);
                intent.putExtra("playerTwo", edit_text2);
                startActivity(intent);
                finish();}


            } });
        ImageButton imageButton = (ImageButton) findViewById(R.id.imageHome);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent packageContext;
                Intent intent = new Intent(Details.this, Home.class);
                startActivity(intent);
                finish();
            }
        });

    }}
